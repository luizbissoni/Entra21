﻿namespace ExemploWFA
{
    partial class Exemplo03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txb_Nome1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.nud_Quantidade1 = new System.Windows.Forms.NumericUpDown();
            this.mtb_Valor1 = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.mtb_Valor2 = new System.Windows.Forms.MaskedTextBox();
            this.nud_Quantidade2 = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.txb_Nome2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.mtb_Valor3 = new System.Windows.Forms.MaskedTextBox();
            this.nud_Quantidade3 = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.txb_Nome3 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.rb_Somar = new System.Windows.Forms.RadioButton();
            this.rb_Media = new System.Windows.Forms.RadioButton();
            this.rb_Menor = new System.Windows.Forms.RadioButton();
            this.rb_Maior = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Quantidade1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Quantidade2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Quantidade3)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome:";
            // 
            // txb_Nome1
            // 
            this.txb_Nome1.Location = new System.Drawing.Point(56, 11);
            this.txb_Nome1.Name = "txb_Nome1";
            this.txb_Nome1.Size = new System.Drawing.Size(100, 20);
            this.txb_Nome1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(162, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Quantidade:";
            // 
            // nud_Quantidade1
            // 
            this.nud_Quantidade1.Location = new System.Drawing.Point(233, 11);
            this.nud_Quantidade1.Name = "nud_Quantidade1";
            this.nud_Quantidade1.Size = new System.Drawing.Size(42, 20);
            this.nud_Quantidade1.TabIndex = 4;
            // 
            // mtb_Valor1
            // 
            this.mtb_Valor1.Location = new System.Drawing.Point(321, 11);
            this.mtb_Valor1.Mask = "990.00";
            this.mtb_Valor1.Name = "mtb_Valor1";
            this.mtb_Valor1.Size = new System.Drawing.Size(43, 20);
            this.mtb_Valor1.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(281, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Valor:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(281, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Valor:";
            // 
            // mtb_Valor2
            // 
            this.mtb_Valor2.Location = new System.Drawing.Point(321, 37);
            this.mtb_Valor2.Mask = "990.00";
            this.mtb_Valor2.Name = "mtb_Valor2";
            this.mtb_Valor2.Size = new System.Drawing.Size(43, 20);
            this.mtb_Valor2.TabIndex = 11;
            // 
            // nud_Quantidade2
            // 
            this.nud_Quantidade2.Location = new System.Drawing.Point(233, 37);
            this.nud_Quantidade2.Name = "nud_Quantidade2";
            this.nud_Quantidade2.Size = new System.Drawing.Size(42, 20);
            this.nud_Quantidade2.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(162, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Quantidade:";
            // 
            // txb_Nome2
            // 
            this.txb_Nome2.Location = new System.Drawing.Point(56, 37);
            this.txb_Nome2.Name = "txb_Nome2";
            this.txb_Nome2.Size = new System.Drawing.Size(100, 20);
            this.txb_Nome2.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 41);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Nome:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(281, 67);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 13);
            this.label7.TabIndex = 18;
            this.label7.Text = "Valor:";
            // 
            // mtb_Valor3
            // 
            this.mtb_Valor3.Location = new System.Drawing.Point(321, 63);
            this.mtb_Valor3.Mask = "990.00";
            this.mtb_Valor3.Name = "mtb_Valor3";
            this.mtb_Valor3.Size = new System.Drawing.Size(43, 20);
            this.mtb_Valor3.TabIndex = 17;
            // 
            // nud_Quantidade3
            // 
            this.nud_Quantidade3.Location = new System.Drawing.Point(233, 63);
            this.nud_Quantidade3.Name = "nud_Quantidade3";
            this.nud_Quantidade3.Size = new System.Drawing.Size(42, 20);
            this.nud_Quantidade3.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(162, 67);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Quantidade:";
            // 
            // txb_Nome3
            // 
            this.txb_Nome3.Location = new System.Drawing.Point(56, 63);
            this.txb_Nome3.Name = "txb_Nome3";
            this.txb_Nome3.Size = new System.Drawing.Size(100, 20);
            this.txb_Nome3.TabIndex = 14;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 67);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "Nome:";
            // 
            // rb_Somar
            // 
            this.rb_Somar.AutoSize = true;
            this.rb_Somar.Location = new System.Drawing.Point(15, 89);
            this.rb_Somar.Name = "rb_Somar";
            this.rb_Somar.Size = new System.Drawing.Size(55, 17);
            this.rb_Somar.TabIndex = 19;
            this.rb_Somar.TabStop = true;
            this.rb_Somar.Text = "Somar";
            this.rb_Somar.UseVisualStyleBackColor = true;
            // 
            // rb_Media
            // 
            this.rb_Media.AutoSize = true;
            this.rb_Media.Location = new System.Drawing.Point(76, 89);
            this.rb_Media.Name = "rb_Media";
            this.rb_Media.Size = new System.Drawing.Size(54, 17);
            this.rb_Media.TabIndex = 20;
            this.rb_Media.TabStop = true;
            this.rb_Media.Text = "Média";
            this.rb_Media.UseVisualStyleBackColor = true;
            // 
            // rb_Menor
            // 
            this.rb_Menor.AutoSize = true;
            this.rb_Menor.Location = new System.Drawing.Point(136, 89);
            this.rb_Menor.Name = "rb_Menor";
            this.rb_Menor.Size = new System.Drawing.Size(55, 17);
            this.rb_Menor.TabIndex = 21;
            this.rb_Menor.TabStop = true;
            this.rb_Menor.Text = "Menor";
            this.rb_Menor.UseVisualStyleBackColor = true;
            // 
            // rb_Maior
            // 
            this.rb_Maior.AutoSize = true;
            this.rb_Maior.Location = new System.Drawing.Point(197, 89);
            this.rb_Maior.Name = "rb_Maior";
            this.rb_Maior.Size = new System.Drawing.Size(51, 17);
            this.rb_Maior.TabIndex = 22;
            this.rb_Maior.TabStop = true;
            this.rb_Maior.Text = "Maior";
            this.rb_Maior.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(136, 139);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 41);
            this.button1.TabIndex = 23;
            this.button1.Text = "Executar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Exemplo03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(378, 206);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.rb_Maior);
            this.Controls.Add(this.rb_Menor);
            this.Controls.Add(this.rb_Media);
            this.Controls.Add(this.rb_Somar);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.mtb_Valor3);
            this.Controls.Add(this.nud_Quantidade3);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txb_Nome3);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.mtb_Valor2);
            this.Controls.Add(this.nud_Quantidade2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txb_Nome2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.mtb_Valor1);
            this.Controls.Add(this.nud_Quantidade1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txb_Nome1);
            this.Controls.Add(this.label1);
            this.Name = "Exemplo03";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Exemplo03";
            ((System.ComponentModel.ISupportInitialize)(this.nud_Quantidade1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Quantidade2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Quantidade3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txb_Nome1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nud_Quantidade1;
        private System.Windows.Forms.MaskedTextBox mtb_Valor1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox mtb_Valor2;
        private System.Windows.Forms.NumericUpDown nud_Quantidade2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txb_Nome2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.MaskedTextBox mtb_Valor3;
        private System.Windows.Forms.NumericUpDown nud_Quantidade3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txb_Nome3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton rb_Somar;
        private System.Windows.Forms.RadioButton rb_Media;
        private System.Windows.Forms.RadioButton rb_Menor;
        private System.Windows.Forms.RadioButton rb_Maior;
        private System.Windows.Forms.Button button1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaEstruturaCondicionalWhile
{
    public class Principal
    {
        static void Main(string[] args)
        {
            //new ExercicioAuxs();
            //new Exercicio01();
            //new Exercicio02();
            //new Exercicio03();
            //new Exercicio04();       //Falta contas as letras
            //new Exercicio05();
            //new Exercicio06();    
            //new Exercicio07();    
            //new Exercicio08();    
            //new Exercicio09();    
            //new Exercicio10();    //Estudar 
            //new Exercicio11();
            //new Exercicio12();
            //new Exercicio13();
            //new Exercicio14();
            //new Exercicio15();  
            //new Exercicio16();


        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gerenciador_DePoneisOO
{
    class Poney
    {
        public string Apelido;
        public string Raca;
        public int Nivelfofura;
        public string CorCrista;
        public double Preco;
        public bool VendaVivo;
        public bool Dancarino;
        public string Localidade;
        public string Descricao;

    }
}

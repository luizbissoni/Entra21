﻿namespace Lista07BancoDadosInterfaceGráfica
{
    partial class CadastroAlunos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Salvar = new System.Windows.Forms.Button();
            this.txt_ID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Nome = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_Nota_1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_Nota_2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_Nota_3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_Frequencia = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_CodigoAluno = new System.Windows.Forms.TextBox();
            this.lbl = new System.Windows.Forms.Label();
            this.lbl_MediaNotas = new System.Windows.Forms.Label();
            this.txt_MatriculaAluno = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.lbl_SituacaoAluno = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Location = new System.Drawing.Point(168, 254);
            this.btn_Salvar.Name = "btn_Salvar";
            this.btn_Salvar.Size = new System.Drawing.Size(75, 23);
            this.btn_Salvar.TabIndex = 0;
            this.btn_Salvar.Text = "Salvar";
            this.btn_Salvar.UseVisualStyleBackColor = true;
            this.btn_Salvar.Click += new System.EventHandler(this.btn_Salvar_Click);
            // 
            // txt_ID
            // 
            this.txt_ID.Enabled = false;
            this.txt_ID.Location = new System.Drawing.Point(230, 12);
            this.txt_ID.Name = "txt_ID";
            this.txt_ID.Size = new System.Drawing.Size(26, 20);
            this.txt_ID.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Nome";
            // 
            // txt_Nome
            // 
            this.txt_Nome.Location = new System.Drawing.Point(59, 67);
            this.txt_Nome.Name = "txt_Nome";
            this.txt_Nome.Size = new System.Drawing.Size(127, 20);
            this.txt_Nome.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(77, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Nota 1";
            // 
            // txt_Nota_1
            // 
            this.txt_Nota_1.Location = new System.Drawing.Point(123, 93);
            this.txt_Nota_1.Name = "txt_Nota_1";
            this.txt_Nota_1.Size = new System.Drawing.Size(63, 20);
            this.txt_Nota_1.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(77, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Nota 2";
            // 
            // txt_Nota_2
            // 
            this.txt_Nota_2.Location = new System.Drawing.Point(123, 119);
            this.txt_Nota_2.Name = "txt_Nota_2";
            this.txt_Nota_2.Size = new System.Drawing.Size(63, 20);
            this.txt_Nota_2.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(77, 152);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Nota 3";
            // 
            // txt_Nota_3
            // 
            this.txt_Nota_3.Location = new System.Drawing.Point(123, 145);
            this.txt_Nota_3.Name = "txt_Nota_3";
            this.txt_Nota_3.Size = new System.Drawing.Size(63, 20);
            this.txt_Nota_3.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(56, 178);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Frequencia";
            // 
            // txt_Frequencia
            // 
            this.txt_Frequencia.Location = new System.Drawing.Point(123, 171);
            this.txt_Frequencia.Name = "txt_Frequencia";
            this.txt_Frequencia.Size = new System.Drawing.Size(63, 20);
            this.txt_Frequencia.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Matricula";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(206, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(18, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "ID";
            // 
            // txt_CodigoAluno
            // 
            this.txt_CodigoAluno.Location = new System.Drawing.Point(91, 15);
            this.txt_CodigoAluno.Name = "txt_CodigoAluno";
            this.txt_CodigoAluno.Size = new System.Drawing.Size(58, 20);
            this.txt_CodigoAluno.TabIndex = 14;
            this.txt_CodigoAluno.Leave += new System.EventHandler(this.txt_CodigoAluno_Leave);
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Location = new System.Drawing.Point(18, 221);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(97, 13);
            this.lbl.TabIndex = 16;
            this.lbl.Text = "Situação do Aluno:";
            // 
            // lbl_MediaNotas
            // 
            this.lbl_MediaNotas.AutoSize = true;
            this.lbl_MediaNotas.Location = new System.Drawing.Point(120, 221);
            this.lbl_MediaNotas.Name = "lbl_MediaNotas";
            this.lbl_MediaNotas.Size = new System.Drawing.Size(0, 13);
            this.lbl_MediaNotas.TabIndex = 17;
            // 
            // txt_MatriculaAluno
            // 
            this.txt_MatriculaAluno.Location = new System.Drawing.Point(57, 44);
            this.txt_MatriculaAluno.Name = "txt_MatriculaAluno";
            this.txt_MatriculaAluno.Size = new System.Drawing.Size(58, 20);
            this.txt_MatriculaAluno.TabIndex = 18;
            this.txt_MatriculaAluno.Leave += new System.EventHandler(this.txt_MatriculaAluno_Leave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(35, 19);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 13);
            this.label8.TabIndex = 19;
            this.label8.Text = "Codigo";
            // 
            // lbl_SituacaoAluno
            // 
            this.lbl_SituacaoAluno.AutoSize = true;
            this.lbl_SituacaoAluno.Location = new System.Drawing.Point(120, 221);
            this.lbl_SituacaoAluno.Name = "lbl_SituacaoAluno";
            this.lbl_SituacaoAluno.Size = new System.Drawing.Size(0, 13);
            this.lbl_SituacaoAluno.TabIndex = 20;
            // 
            // CadastroAlunos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(268, 289);
            this.Controls.Add(this.lbl_SituacaoAluno);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt_MatriculaAluno);
            this.Controls.Add(this.lbl_MediaNotas);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_CodigoAluno);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_Frequencia);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_Nota_3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_Nota_2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_Nota_1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_Nome);
            this.Controls.Add(this.txt_ID);
            this.Controls.Add(this.btn_Salvar);
            this.Name = "CadastroAlunos";
            this.Text = "CadastroAlunos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Salvar;
        private System.Windows.Forms.TextBox txt_ID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_Nome;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_Nota_1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_Nota_2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_Nota_3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_Frequencia;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_CodigoAluno;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.Label lbl_MediaNotas;
        private System.Windows.Forms.TextBox txt_MatriculaAluno;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbl_SituacaoAluno;
    }
}
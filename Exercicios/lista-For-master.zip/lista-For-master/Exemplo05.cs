﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExemploFor
{
    class Exemplo05
    {
        public Exemplo05()
        {
            for (int h = 0; h < 2; h++)
            {
                
            for (int i = 0; i < 1; i++)
            {
                Console.Write("**********");

                for (int j = 0; j < 1; j++)
                {
                    Console.WriteLine("**********");
                }

            }
            }
        }
    }
}

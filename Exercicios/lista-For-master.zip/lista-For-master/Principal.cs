﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExemploFor
{
    public class Principal
    {

        static void Main(string[] args)
        {
            //new Exemplo01();
            //new Exemplo02();
            //new Exemplo03();
            //new Exemplo04();
            //new Exemplo05();

        }
    }
}

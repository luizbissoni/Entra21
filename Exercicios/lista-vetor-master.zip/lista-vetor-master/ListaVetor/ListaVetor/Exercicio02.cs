﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ListaVetor
{
    class Exercicio02
    {
        public Exercicio02()
        {
            string[] Nomes = new string[10];

            Nomes[0] = "AAAA";
            Nomes[1] = "BBBB";
            Nomes[2] = "CCCC";
            Nomes[3] = "DDDD";
            Nomes[4] = "EEEE";
            Nomes[5] = "FFFF";
            Nomes[6] = "GGGG";
            Nomes[7] = "HHHH";
            Nomes[8] = "IIII";
            Nomes[9] = "JJJJ";

            Console.WriteLine(Nomes[0] + ", "+Nomes[1]+ ", "+Nomes[2]+ ", "+Nomes[3]+ ", "+Nomes[4]+ ", "+Nomes[5]+ ", "+Nomes[6]+ ", "+Nomes[7]+ ", "+Nomes[8]+ ", "+Nomes[9]); 
            
        }
    }
}

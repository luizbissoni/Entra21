﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista_de_Estrutura_Condicional___Forms
{
    public partial class MenuPrincipal : Form
    {
        public MenuPrincipal()
        {
            InitializeComponent();
        }

        private void btn_Exercicio01_Click(object sender, EventArgs e)
        {
            Exercicio01 exercicio01 = new Exercicio01();
            exercicio01.Show();
        }

        private void btn_Exercicio02_Click(object sender, EventArgs e)
        {
            Exercicio02 exercicio02 = new Exercicio02();
            exercicio02.Show();
        }

        private void btn_Exercicio03_Click(object sender, EventArgs e)
        {
            Exercicio03 exercicio03 = new Exercicio03();
            exercicio03.Show();
        }

        private void btn_Exercicio04_Click(object sender, EventArgs e)
        {
            Exercicio04 exercicio04 = new Exercicio04();
            exercicio04.Show();
        }

        private void btn_Exercicio05_Click(object sender, EventArgs e)
        {
            //Exercicio05 exercicio05 = new Exercicio05();
            //exercicio05.Show();
        }

        private void btn_Exercicio06_Click(object sender, EventArgs e)
        {
            Exercicio06 exercicio06 = new Exercicio06();
            exercicio06.Show();
        }

        private void btn_Exercicio07_Click_1(object sender, EventArgs e)
        {
            Exercicio07 exercicio07 = new Exercicio07();
            exercicio07.Show();
        }

        private void btn_Exercicio08_Click(object sender, EventArgs e)
        {
            Exercicio08 exercicio08 = new Exercicio08();
            exercicio08.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Exercicio09 exercicio09 = new Exercicio09();
            exercicio09.Show();
        }

        private void btn_Exercicio10_Click(object sender, EventArgs e)
        {
            Exercicio10 exercicio10 = new Exercicio10();
            exercicio10.Show();
        }

        private void btn_Exercicio11_Click(object sender, EventArgs e)
        {
            Exercicio11 exercicio11 = new Exercicio11();
            exercicio11.Show();
        }

        private void btn_Exercicio12_Click(object sender, EventArgs e)
        {
            Exercicio12 exercicio12 = new Exercicio12();
            exercicio12.Show();
        }

        private void btn_Exercicio13_Click(object sender, EventArgs e)
        {
            Exercicio13 exercicio13 = new Exercicio13();
            exercicio13.Show();
        }

        private void btn_Exercicio16_Click(object sender, EventArgs e)
        {
            Exercicio16 exercicio16 = new Exercicio16();
            exercicio16.Show();
        }
    }
}

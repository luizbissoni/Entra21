﻿namespace Lista_de_Estrutura_Condicional___Forms
{
    partial class Exercicio08
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_Pedido1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_FinalizarCompra = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_Resultado = new System.Windows.Forms.Label();
            this.lb_TotalPedido = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_Pedido2 = new System.Windows.Forms.TextBox();
            this.txt_Pedido3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txt_Pedido1
            // 
            this.txt_Pedido1.Location = new System.Drawing.Point(644, 27);
            this.txt_Pedido1.Name = "txt_Pedido1";
            this.txt_Pedido1.Size = new System.Drawing.Size(44, 20);
            this.txt_Pedido1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(518, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "Pedido";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(518, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Número do pedido 1";
            // 
            // btn_FinalizarCompra
            // 
            this.btn_FinalizarCompra.Location = new System.Drawing.Point(611, 335);
            this.btn_FinalizarCompra.Name = "btn_FinalizarCompra";
            this.btn_FinalizarCompra.Size = new System.Drawing.Size(127, 47);
            this.btn_FinalizarCompra.TabIndex = 7;
            this.btn_FinalizarCompra.Text = "Finalizar Compra";
            this.btn_FinalizarCompra.UseVisualStyleBackColor = true;
            this.btn_FinalizarCompra.Click += new System.EventHandler(this.btn_FinalizarCompra_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(202, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 18);
            this.label1.TabIndex = 8;
            this.label1.Text = "Produtos";
            // 
            // lb_Resultado
            // 
            this.lb_Resultado.AutoSize = true;
            this.lb_Resultado.Location = new System.Drawing.Point(38, 67);
            this.lb_Resultado.Name = "lb_Resultado";
            this.lb_Resultado.Size = new System.Drawing.Size(0, 13);
            this.lb_Resultado.TabIndex = 9;
            // 
            // lb_TotalPedido
            // 
            this.lb_TotalPedido.AutoSize = true;
            this.lb_TotalPedido.Location = new System.Drawing.Point(521, 137);
            this.lb_TotalPedido.Name = "lb_TotalPedido";
            this.lb_TotalPedido.Size = new System.Drawing.Size(0, 13);
            this.lb_TotalPedido.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(518, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 15);
            this.label4.TabIndex = 11;
            this.label4.Text = "Número do pedido 2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(518, 77);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 15);
            this.label5.TabIndex = 12;
            this.label5.Text = "Número do pedido 3";
            // 
            // txt_Pedido2
            // 
            this.txt_Pedido2.Location = new System.Drawing.Point(644, 52);
            this.txt_Pedido2.Name = "txt_Pedido2";
            this.txt_Pedido2.Size = new System.Drawing.Size(44, 20);
            this.txt_Pedido2.TabIndex = 13;
            // 
            // txt_Pedido3
            // 
            this.txt_Pedido3.Location = new System.Drawing.Point(644, 77);
            this.txt_Pedido3.Name = "txt_Pedido3";
            this.txt_Pedido3.Size = new System.Drawing.Size(44, 20);
            this.txt_Pedido3.TabIndex = 14;
            // 
            // Exercicio08
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 394);
            this.Controls.Add(this.txt_Pedido3);
            this.Controls.Add(this.txt_Pedido2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lb_TotalPedido);
            this.Controls.Add(this.lb_Resultado);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_FinalizarCompra);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_Pedido1);
            this.Name = "Exercicio08";
            this.Text = "Exercicio08";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_Pedido1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_FinalizarCompra;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_Resultado;
        private System.Windows.Forms.Label lb_TotalPedido;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_Pedido2;
        private System.Windows.Forms.TextBox txt_Pedido3;
    }
}
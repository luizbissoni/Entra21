﻿namespace Lista_de_Estrutura_Condicional___Forms
{
    partial class MenuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Exercicio01 = new System.Windows.Forms.Button();
            this.btn_Exercicio02 = new System.Windows.Forms.Button();
            this.btn_Exercicio03 = new System.Windows.Forms.Button();
            this.btn_Exercicio04 = new System.Windows.Forms.Button();
            this.btn_Exercicio05 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Exercicio06 = new System.Windows.Forms.Button();
            this.btn_Exercicio07 = new System.Windows.Forms.Button();
            this.btn_Exercicio08 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.btn_Exercicio10 = new System.Windows.Forms.Button();
            this.btn_Exercicio11 = new System.Windows.Forms.Button();
            this.btn_Exercicio12 = new System.Windows.Forms.Button();
            this.btn_Exercicio13 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.btn_Exercicio16 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Exercicio01
            // 
            this.btn_Exercicio01.Location = new System.Drawing.Point(12, 56);
            this.btn_Exercicio01.Name = "btn_Exercicio01";
            this.btn_Exercicio01.Size = new System.Drawing.Size(75, 23);
            this.btn_Exercicio01.TabIndex = 1;
            this.btn_Exercicio01.Text = "Exercicio 01";
            this.btn_Exercicio01.UseVisualStyleBackColor = true;
            this.btn_Exercicio01.Click += new System.EventHandler(this.btn_Exercicio01_Click);
            // 
            // btn_Exercicio02
            // 
            this.btn_Exercicio02.Location = new System.Drawing.Point(93, 56);
            this.btn_Exercicio02.Name = "btn_Exercicio02";
            this.btn_Exercicio02.Size = new System.Drawing.Size(75, 23);
            this.btn_Exercicio02.TabIndex = 2;
            this.btn_Exercicio02.Text = "Exercicio 02";
            this.btn_Exercicio02.UseVisualStyleBackColor = true;
            this.btn_Exercicio02.Click += new System.EventHandler(this.btn_Exercicio02_Click);
            // 
            // btn_Exercicio03
            // 
            this.btn_Exercicio03.Location = new System.Drawing.Point(174, 56);
            this.btn_Exercicio03.Name = "btn_Exercicio03";
            this.btn_Exercicio03.Size = new System.Drawing.Size(75, 23);
            this.btn_Exercicio03.TabIndex = 3;
            this.btn_Exercicio03.Text = "Exercicio 03";
            this.btn_Exercicio03.UseVisualStyleBackColor = true;
            this.btn_Exercicio03.Click += new System.EventHandler(this.btn_Exercicio03_Click);
            // 
            // btn_Exercicio04
            // 
            this.btn_Exercicio04.Location = new System.Drawing.Point(12, 85);
            this.btn_Exercicio04.Name = "btn_Exercicio04";
            this.btn_Exercicio04.Size = new System.Drawing.Size(75, 23);
            this.btn_Exercicio04.TabIndex = 4;
            this.btn_Exercicio04.Text = "Exercicio 04";
            this.btn_Exercicio04.UseVisualStyleBackColor = true;
            this.btn_Exercicio04.Click += new System.EventHandler(this.btn_Exercicio04_Click);
            // 
            // btn_Exercicio05
            // 
            this.btn_Exercicio05.Location = new System.Drawing.Point(93, 85);
            this.btn_Exercicio05.Name = "btn_Exercicio05";
            this.btn_Exercicio05.Size = new System.Drawing.Size(75, 23);
            this.btn_Exercicio05.TabIndex = 5;
            this.btn_Exercicio05.Text = "Exercicio 05";
            this.btn_Exercicio05.UseVisualStyleBackColor = true;
            this.btn_Exercicio05.Click += new System.EventHandler(this.btn_Exercicio05_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(251, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Lista 02 Estrutura Condicional";
            // 
            // btn_Exercicio06
            // 
            this.btn_Exercicio06.Location = new System.Drawing.Point(174, 84);
            this.btn_Exercicio06.Name = "btn_Exercicio06";
            this.btn_Exercicio06.Size = new System.Drawing.Size(75, 23);
            this.btn_Exercicio06.TabIndex = 6;
            this.btn_Exercicio06.Text = "Exercicio 06";
            this.btn_Exercicio06.UseVisualStyleBackColor = true;
            this.btn_Exercicio06.Click += new System.EventHandler(this.btn_Exercicio06_Click);
            // 
            // btn_Exercicio07
            // 
            this.btn_Exercicio07.Location = new System.Drawing.Point(12, 114);
            this.btn_Exercicio07.Name = "btn_Exercicio07";
            this.btn_Exercicio07.Size = new System.Drawing.Size(75, 23);
            this.btn_Exercicio07.TabIndex = 7;
            this.btn_Exercicio07.Text = "Exercicio 07";
            this.btn_Exercicio07.UseVisualStyleBackColor = true;
            this.btn_Exercicio07.Click += new System.EventHandler(this.btn_Exercicio07_Click_1);
            // 
            // btn_Exercicio08
            // 
            this.btn_Exercicio08.Location = new System.Drawing.Point(93, 114);
            this.btn_Exercicio08.Name = "btn_Exercicio08";
            this.btn_Exercicio08.Size = new System.Drawing.Size(75, 23);
            this.btn_Exercicio08.TabIndex = 8;
            this.btn_Exercicio08.Text = "Exercicio 08";
            this.btn_Exercicio08.UseVisualStyleBackColor = true;
            this.btn_Exercicio08.Click += new System.EventHandler(this.btn_Exercicio08_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(174, 114);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 9;
            this.button4.Text = "Exercicio 09";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btn_Exercicio10
            // 
            this.btn_Exercicio10.Location = new System.Drawing.Point(12, 143);
            this.btn_Exercicio10.Name = "btn_Exercicio10";
            this.btn_Exercicio10.Size = new System.Drawing.Size(75, 23);
            this.btn_Exercicio10.TabIndex = 10;
            this.btn_Exercicio10.Text = "Exercicio 10";
            this.btn_Exercicio10.UseVisualStyleBackColor = true;
            this.btn_Exercicio10.Click += new System.EventHandler(this.btn_Exercicio10_Click);
            // 
            // btn_Exercicio11
            // 
            this.btn_Exercicio11.Location = new System.Drawing.Point(93, 143);
            this.btn_Exercicio11.Name = "btn_Exercicio11";
            this.btn_Exercicio11.Size = new System.Drawing.Size(75, 23);
            this.btn_Exercicio11.TabIndex = 11;
            this.btn_Exercicio11.Text = "Exercicio 11";
            this.btn_Exercicio11.UseVisualStyleBackColor = true;
            this.btn_Exercicio11.Click += new System.EventHandler(this.btn_Exercicio11_Click);
            // 
            // btn_Exercicio12
            // 
            this.btn_Exercicio12.Location = new System.Drawing.Point(174, 143);
            this.btn_Exercicio12.Name = "btn_Exercicio12";
            this.btn_Exercicio12.Size = new System.Drawing.Size(75, 23);
            this.btn_Exercicio12.TabIndex = 12;
            this.btn_Exercicio12.Text = "Exercicio12";
            this.btn_Exercicio12.UseVisualStyleBackColor = true;
            this.btn_Exercicio12.Click += new System.EventHandler(this.btn_Exercicio12_Click);
            // 
            // btn_Exercicio13
            // 
            this.btn_Exercicio13.Location = new System.Drawing.Point(12, 172);
            this.btn_Exercicio13.Name = "btn_Exercicio13";
            this.btn_Exercicio13.Size = new System.Drawing.Size(75, 23);
            this.btn_Exercicio13.TabIndex = 13;
            this.btn_Exercicio13.Text = "Exercicio 13";
            this.btn_Exercicio13.UseVisualStyleBackColor = true;
            this.btn_Exercicio13.Click += new System.EventHandler(this.btn_Exercicio13_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(93, 172);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 14;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(174, 172);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 15;
            this.button10.Text = "button10";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // btn_Exercicio16
            // 
            this.btn_Exercicio16.Location = new System.Drawing.Point(12, 201);
            this.btn_Exercicio16.Name = "btn_Exercicio16";
            this.btn_Exercicio16.Size = new System.Drawing.Size(75, 23);
            this.btn_Exercicio16.TabIndex = 16;
            this.btn_Exercicio16.Text = "Exercicio 16";
            this.btn_Exercicio16.UseVisualStyleBackColor = true;
            this.btn_Exercicio16.Click += new System.EventHandler(this.btn_Exercicio16_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(93, 201);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 17;
            this.button12.Text = "button12";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(174, 201);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 23);
            this.button13.TabIndex = 18;
            this.button13.Text = "button13";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(12, 226);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 23);
            this.button14.TabIndex = 19;
            this.button14.Text = "button14";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(93, 226);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 23);
            this.button15.TabIndex = 20;
            this.button15.Text = "button15";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(174, 226);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 23);
            this.button16.TabIndex = 21;
            this.button16.Text = "button16";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(12, 255);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 23);
            this.button17.TabIndex = 22;
            this.button17.Text = "button17";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(93, 255);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(75, 23);
            this.button18.TabIndex = 23;
            this.button18.Text = "button18";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(174, 255);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(75, 23);
            this.button19.TabIndex = 24;
            this.button19.Text = "button19";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(12, 284);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(75, 23);
            this.button20.TabIndex = 25;
            this.button20.Text = "button20";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(93, 284);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(75, 23);
            this.button21.TabIndex = 26;
            this.button21.Text = "button21";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // MenuPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 322);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.btn_Exercicio16);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.btn_Exercicio13);
            this.Controls.Add(this.btn_Exercicio12);
            this.Controls.Add(this.btn_Exercicio11);
            this.Controls.Add(this.btn_Exercicio10);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.btn_Exercicio08);
            this.Controls.Add(this.btn_Exercicio07);
            this.Controls.Add(this.btn_Exercicio06);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Exercicio05);
            this.Controls.Add(this.btn_Exercicio04);
            this.Controls.Add(this.btn_Exercicio03);
            this.Controls.Add(this.btn_Exercicio02);
            this.Controls.Add(this.btn_Exercicio01);
            this.Name = "MenuPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Exercicio01;
        private System.Windows.Forms.Button btn_Exercicio02;
        private System.Windows.Forms.Button btn_Exercicio03;
        private System.Windows.Forms.Button btn_Exercicio04;
        private System.Windows.Forms.Button btn_Exercicio05;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Exercicio06;
        private System.Windows.Forms.Button btn_Exercicio07;
        private System.Windows.Forms.Button btn_Exercicio08;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btn_Exercicio10;
        private System.Windows.Forms.Button btn_Exercicio11;
        private System.Windows.Forms.Button btn_Exercicio12;
        private System.Windows.Forms.Button btn_Exercicio13;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button btn_Exercicio16;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;

    }
}


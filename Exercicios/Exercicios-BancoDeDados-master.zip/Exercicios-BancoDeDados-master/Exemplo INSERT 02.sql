﻿CREATE TABLE mangas
(
nome VARCHAR(100),
volume INT,
ano INT
);

INSERT INTO mangas VALUES('NARUTO',67,2015);
INSERT INTO mangas VALUES('bleach',70,2015);
INSERT INTO mangas VALUES('nanatsu', 20,2015);
INSERT INTO mangas VALUES('dragon ball',8001,2004);

SELECT * FROM mangas;
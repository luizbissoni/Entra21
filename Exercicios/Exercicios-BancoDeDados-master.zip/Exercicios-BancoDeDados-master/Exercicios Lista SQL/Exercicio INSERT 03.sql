﻿CREATE TABLE [dbo].[champions] (
    [nome]        VARCHAR (100) NULL,
    [descricao]   VARCHAR (100) NULL,
    [habilidade1] VARCHAR (100) NULL,
    [habilidade2] VARCHAR (100) NULL,
    [habilidade3] VARCHAR (100) NULL,
    [habilidade4] VARCHAR (100) NULL,
    [habilidade5] VARCHAR (100) NULL
);


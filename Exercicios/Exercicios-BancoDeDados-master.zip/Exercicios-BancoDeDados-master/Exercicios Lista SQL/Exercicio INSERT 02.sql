﻿--DROP TABLE enderecos;

CREATE TABLE enderecos
(
	estado	CHAR(2),
	cidade	VARCHAR(140),
	bairro	VARCHAR(120),
	cep		CHAR(10),
	logradouro	VARCHAR(250),
	numero	SMALLINT,
	complemento		TEXT
);

INSERT INTO pessoas VALUES('AC','Rio Branco','Ayrton Senna','69.911-866','Estrada Deputado José Rui da Silveira Lino',282,'CASA');
INSERT INTO pessoas VALUES('SC','Biguaçu','Fundos','88.161-400','Estrada Deputado José Rui da Silveira Lino',282,'CASA');
INSERT INTO pessoas VALUES('AC','Rio Branco','Ayrton Senna','69.911-866','Estrada Deputado José Rui da Silveira Lino',282,'CASA');
INSERT INTO pessoas VALUES('AC','Rio Branco','Ayrton Senna','69.911-866','Estrada Deputado José Rui da Silveira Lino',282,'CASA');
INSERT INTO pessoas VALUES('AC','Rio Branco','Ayrton Senna','69.911-866','Estrada Deputado José Rui da Silveira Lino',282,'CASA');
INSERT INTO pessoas VALUES('AC','Rio Branco','Ayrton Senna','69.911-866','Estrada Deputado José Rui da Silveira Lino',282,'CASA');
INSERT INTO pessoas VALUES('AC','Rio Branco','Ayrton Senna','69.911-866','Estrada Deputado José Rui da Silveira Lino',282,'CASA');
INSERT INTO pessoas VALUES('AC','Rio Branco','Ayrton Senna','69.911-866','Estrada Deputado José Rui da Silveira Lino',282,'CASA');
INSERT INTO pessoas VALUES('AC','Rio Branco','Ayrton Senna','69.911-866','Estrada Deputado José Rui da Silveira Lino',282,'CASA');
INSERT INTO pessoas VALUES('AC','Rio Branco','Ayrton Senna','69.911-866','Estrada Deputado José Rui da Silveira Lino',282,'CASA');

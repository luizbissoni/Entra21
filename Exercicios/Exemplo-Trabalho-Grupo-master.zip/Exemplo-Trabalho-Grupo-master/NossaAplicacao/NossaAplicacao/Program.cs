﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NossaAplicacao
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Eu\"Luiz Antonio Bissoni\" quero imprimir" );
<<<<<<< HEAD
            Console.WriteLine();
=======
            Console.WriteLine("Eu \"Francisco Lucas Sens\" mandei imprimir");
>>>>>>> 6024353886135944fa87d607fb978d7776651cd6
        }
    }
}

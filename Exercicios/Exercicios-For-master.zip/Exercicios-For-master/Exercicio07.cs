﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExerciciosFor
{
    class Exercicio07
    {
        public Exercicio07()
        {
            char[] vetorCaracteres = new char[20];
            
            for (int i = 0; i < vetorCaracteres.Length; i++)
            {
                Console.WriteLine("Digite um caracter: ");
                vetorCaracteres[i] = Convert.ToChar(Console.ReadLine());
            }
            for (int i = 0; i < vetorCaracteres.Length; i++)
            {
                
            }
        }
    }
}

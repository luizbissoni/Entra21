﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExerciciosFor
{
    class Principal
    {
        static void Main(string[] args)
        {
            new Exercicio01();
            //new Exercicio02();
            //new Exercicio03();
            //new Exercicio04();
            //new Exercicio05();
            //new Exercicio06();
            //new Exercicio07();
            //new Exercicio08();
            //new Exercicio09();
            //new Exercicio10();
            //new Exercicio11();
           
        }
    }
}

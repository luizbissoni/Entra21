﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaExercicios02
{
    class Exercicio08
    {
        static void Main8(string[] args)
        {

            double NumeroPedido1 = 29.50;
            double NumeroPedido2 = 30.50;
            double NumeroPedido3 = 27.99;
            double NumeroPedido4 = 25.90;
            double NumeroPedido5 = 20.65;
            double NumeroPedido6 = 3.50;
            double NumeroPedido7 = 4.99;
            double NumeroPedido8 = 25.69;
            double NumeroPedido9 = 15.60;
            double NumeroPedido10 = 10.50;
            double NumeroPedido11 = 19.30;
            double NumeroPedido12 = 15.89;
            double NumeroPedido13 = 19.90;
            double NumeroPedido14 = 21.75;
            double NumeroPedido15 = 26.50; 



            Console.WriteLine( 
                                     "Tipo " + "      Nome   " + "                                                   Valor "+ "\n"+
                                     "1 "+"Bolos    " + "Bolo Brigadeiro                                              " +"R$29,50" +"\n"+
                                     "2 "+"Bolos    " + "Bolo Floresta Negra                                          " +"R$30,50"+"\n"+
                                     "3 "+"Bolos    " + "Bolo Leite Com nutella                                       " +"R$27,99"+"\n"+   
                                     "4 "+"Bolos    " + "Bolo Mousse de Chocolate                                     " +"R$25,50"+"\n"+
                                     "5 "+"Bolos    " + "Bolo Nega Maluca                                             " +"R$20,65"+"\n"+
                                     "6 "+"Doces    " + "Bomba de Creme                                               " +"R$3,50"+"\n"+
                                     "7 "+"Doces    " + "Bomba de Morango                                             " +"R$4,99"+"\n"+
                                     "8 "+"Sanduiches    " + "Filé-Mignon com fritas e Cheddar                        "+"R$25,69"+"\n"+
                                     "9 "+"Sanduiches    " + "Hambúrguer com Queijo,Champignon e rúcula               " +"R$15,60"+"\n"+
                                     "10 "+"Sanduiches    " + "Provolone com salame                                    " +"R$10,50"+"\n"+
                                     "11 "+"Sanduiches    " + "Vegetariano de berinjela                                " +"R$19,30"+"\n"+
                                     "12 "+"Pizzas    " + "Calabresa                                                   " +"R$15,89"+"\n"+
                                     "13 "+"Pizzas    " + "Napolitana                                                  " +"R$19,90"+"\n"+
                                     "14 "+"Pizzas    " + "Peruana                                                     " +"R$21,75"+"\n"+
                                     "15 "+"Pizzas    " + "Portuguesa                                                  " +"R$26,50"
            
                                  );
            Console.WriteLine("");
            double Pedido1 = Convert.ToDouble(Console.ReadLine());
           
            if (Pedido1 == 1)
            {
                Pedido1 = NumeroPedido1;
            }
            else if (Pedido1 == 2)
            {
                Pedido1 = NumeroPedido2;
            }
            else if (Pedido1 == 3)
            {
                Pedido1 = NumeroPedido3;
            }
            else if (Pedido1 == 4)
            {
                Pedido1 = NumeroPedido4;
            }
            else if (Pedido1 == 5)
            {
                Pedido1 = NumeroPedido5;
            }
            else if (Pedido1 == 6)
            {
                Pedido1 = NumeroPedido6;
            }
            else if (Pedido1 == 7)
            {
                Pedido1 = NumeroPedido7;
            }
            else if (Pedido1 == 8)
            {
                Pedido1 = NumeroPedido8;
            }
            else if (Pedido1 == 9)
            {
                Pedido1 = NumeroPedido9;
            }
            else if (Pedido1 == 10)
            {
                Pedido1 = NumeroPedido10;
            }
            else if (Pedido1 == 11)
            {
                Pedido1 = NumeroPedido11;
            }
            else if (Pedido1 == 12)
            {
                Pedido1 = NumeroPedido12;
            }
            else if (Pedido1 == 13)
            {
                Pedido1 = NumeroPedido13;
            }
            else if (Pedido1 == 14)
            {
                Pedido1 = NumeroPedido14;
            }
            else if (Pedido1 == 15)
            {
                Pedido1 = NumeroPedido15;
            }

            Console.Write("");
            double Pedido2 = Convert.ToDouble(Console.ReadLine());
           
            if (Pedido2 == 1)
            {
                Pedido2 = NumeroPedido1;
            }
            else if (Pedido2 == 2)
            {
                Pedido2 = NumeroPedido2;
            }
            else if (Pedido2 == 3)
            {
                Pedido2 = NumeroPedido3;
            }
            else if (Pedido2 == 4)
            {
                Pedido2 = NumeroPedido4;
            }
            else if (Pedido2 == 5)
            {
                Pedido2 = NumeroPedido5;
            }
            else if (Pedido2 == 6)
            {
                Pedido2 = NumeroPedido6;
            }
            else if (Pedido2 == 7)
            {
                Pedido2 = NumeroPedido7;
            }
            else if (Pedido2 == 8)
            {
                Pedido2 = NumeroPedido8;
            }
            else if (Pedido2 == 9)
            {
                Pedido2 = NumeroPedido9;
            }
            else if (Pedido2 == 10)
            {
                Pedido2 = NumeroPedido10;
            }
            else if (Pedido2 == 11)
            {
                Pedido2 = NumeroPedido11;
            }
            else if (Pedido2 == 12)
            {
                Pedido2 = NumeroPedido12;
            }
            else if (Pedido2 == 13)
            {
                Pedido2 = NumeroPedido13;
            }
            else if (Pedido2 == 14)
            {
                Pedido2 = NumeroPedido14;
            }
            else if (Pedido2 == 15)
            {
                Pedido2 = NumeroPedido15;
            }

            Console.Write("");
            double Pedido3 = Convert.ToDouble(Console.ReadLine());
            
            if (Pedido3 == 1)
            {
                Pedido3 = NumeroPedido1;
            }
            else if (Pedido3 == 2)
            {
                Pedido3 = NumeroPedido2;
            }
            else if (Pedido3 == 3)
            {
                Pedido3 = NumeroPedido3;
            }
            else if (Pedido3 == 4)
            {
                Pedido3 = NumeroPedido4;
            }
            else if (Pedido3 == 5)
            {
                Pedido3 = NumeroPedido5;
            }
            else if (Pedido3 == 6)
            {
                Pedido3 = NumeroPedido6;
            }
            else if (Pedido3 == 7)
            {
                Pedido3 = NumeroPedido7;
            }
            else if (Pedido3 == 8)
            {
                Pedido3 = NumeroPedido8;
            }
            else if (Pedido3 == 9)
            {
                Pedido3 = NumeroPedido9;
            }
            else if (Pedido3 == 10)
            {
                Pedido3 = NumeroPedido10;
            }
            else if (Pedido3 == 11)
            {
                Pedido3 = NumeroPedido11;
            }
            else if (Pedido3 == 12)
            {
                Pedido3 = NumeroPedido12;
            }
            else if (Pedido3 == 13)
            {
                Pedido3 = NumeroPedido13;
            }
            else if (Pedido3 == 14)
            {
                Pedido3 = NumeroPedido14;
            }
            else if (Pedido3 == 15)
            {
                Pedido3 = NumeroPedido15;
            }

            double PrecoTotal = Pedido1 + Pedido2 + Pedido3;
            Console.WriteLine("Valor do Total do Pedido: " + PrecoTotal );
           
            

            








           

                                  

            



           

        }
    }
}

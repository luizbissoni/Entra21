﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaExercicios02
{
    class Exercicio14
    {
        static void Main14(string[] args)
        {
            Console.Write("Primeiro número: ");
            double Numero1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Segundo número: ");
            double Numero2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Terceiro número: ");
            double Numero3 = Convert.ToDouble(Console.ReadLine());

           /* double Primeiro = 0;
            double Segunda = 0;
            double Terceira = 0;

            if ((Numero3 > Numero1) && (Numero3 > Numero2))
            {
               
            }*/

        }
    }
}

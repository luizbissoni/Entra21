﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ListaExercicios02;

namespace ListaEstruturaCondicional
{
     public class Principal
    {
         static void Main(string[] args)
         {
             //new Exercicio001();
             //new Exercicio002();
             //new Exercicio003();
             //new Exercicio004();
             //new Exercicio005();
             //new Exercicio006();
             //new Exercicio007();
             //new Exercicio008();
             //new Exercicio009();
             //new Exercicio010();
             //new Exercicio011();
             //new Exercicio012();
             //new Exercicio013();
             //new Exercicio014();
             //new Exercicio015();       //Faz crescente e decrescente  
             //new Exercicio016();      
             //new Exercicio019();
             //new Exercicio020();
             //new Exercicio021();
             //new Exercicio022();
             //new Exercicio023();
             //new Exercicio024();
             //new Exercicio025();
             //new Exercicio026();
         }
    }
}

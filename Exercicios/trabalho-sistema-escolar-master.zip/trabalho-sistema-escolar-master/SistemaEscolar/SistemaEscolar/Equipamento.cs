﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaEscolar
{
    public class Equipamento
    {
        public string NomeEquipamento;
        public string MarcaEquipamento;
        public int QuantidadeEquipamento;
        public DateTime DataEntradaEquipamento;
        public string SetorEquipamento;
    }
}

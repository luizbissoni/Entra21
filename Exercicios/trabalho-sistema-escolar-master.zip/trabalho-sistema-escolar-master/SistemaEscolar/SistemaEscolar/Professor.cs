﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaEscolar
{
    public class Professor
    {
        public string NomeProfessor;
        public string SexoProfessor;
        public string CPFProfessor;
        public string RGProfessor;
        public string TurnoProfessor;
        public string NacionalidadeProfessor;
        public DateTime NascimentoProfessor;        
        public string EspecialidadeProfessor;
        public int NumeroContaSalarioProfessor;
        public int NumeroAgenciaContaSalarioProfessor;
        public string CEPProfessor;
        public string UFProfessor;
        public int NumeroCasaProfessor;
        public string EmailProfessor;
        public string ComplementoProfessor;
    }


}

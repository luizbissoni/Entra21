﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExemploVetorComFor
{
    class Principal
    {
        static void Main(string[] args)
        {
            //new Exemplo01();
            //new Exemplo02();
            new Exemplo03();

        }
    }
}
